/*-------------------------------------------------------------------------

			RAW to POV-Ray Converter
		     Copyright (c) 1993 Steve Anger

   Reads a list of triangle coordinates in raw ASCII text format and
 outputs a POV-Ray 1.0 compatable file. Automatically adds bounding shapes
 and produces smooth triangles. This file may be freely modified and
 distributed.

				      CompuServe: 70714,3113
					Internet: 70714.3113@compuserve.com
				       YCCMR BBS: (708)358-5611

--------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <values.h>
#include <ctype.h>
#include "rayopt.h"

#define VERSION "v1.7"
#define MAX_TEXTURE 400

#ifdef __TURBOC__
extern unsigned _stklen = 16384;
#endif

#define DEFAULT  0
#define FRACTINT 1
#define TEXTURE  2

void process_args (int argc, char *argv[]);
char *next_token (FILE *f);
int parse_input (FILE *f);
void make_camera (void);
void update_txtlist (char *new_texture);
void fswap (float *a, float *b);
char upcase (char c);

typedef struct {
    float x, y, z;
} Vector;


char  infile[64];       /* Name of input file */
char  outfile[64];      /* Name of output file */
float smooth;           /* Smooth triangles with angles < this value */
int   bound;            /* Type of bounding shape to use */
int   verbose;          /* Verbose status messages */
int   one_object;       /* Optimize file as a single object */
int   swap_yz;          /* Swap Y and Z coordinates */
int   camera;           /* Place a camera and light source in scene file */
int   format;           /* Input file format type */
long  line_cnt;         /* Line number */

float ax, ay, az;
float bx, by, bz;
float cx, cy, cz;
float red, green, blue;
char  new_obj_name[80];
char  new_texture[80];

char  *txtlist[MAX_TEXTURE];
int   txtcnt = 0;


int main (int argc, char *argv[])
{
    FILE  *f, *g;
    int   obj_cnt, tri_cnt;
    int   done, i;
    char  obj_name[80] = "";

    process_args (argc, argv);

    f = fopen (infile, "r");

    if (f == NULL) {
	printf ("Error opening input file %s\n", infile);
	exit(1);
    }

    opt_set_dec (4);
    opt_set_bound (bound);
    opt_set_smooth (smooth);
    opt_set_quiet (!verbose);
    opt_set_fname (outfile, "");

    /* Use the name of the file as default object name */
    strcpy (obj_name, infile);
    add_ext (obj_name, "", 1);

    line_cnt = 0;
    obj_cnt = 0;
    tri_cnt = 0;
    done = 0;

    printf ("Reading file...\n");

    while (!done) {
	switch (parse_input (f)) {
	    /* End of file */
	    case  0: done = 1;
		     break;

	    /* New triangle with RGB color */
	    case  1: opt_set_color (red, green, blue);
		     opt_add_tri (ax, ay, az, bx, by, bz, cx, cy, cz);
		     ++tri_cnt;
		     break;

	    /* New triangle with named texture */
	    case  2: update_txtlist (new_texture);
		     opt_set_texture (new_texture);
		     opt_add_tri (ax, ay, az, bx, by, bz, cx, cy, cz);
		     ++tri_cnt;
		     break;

	    /* New object */
	    case  3: if (!one_object) {
			 if (tri_cnt > 0) {
			     opt_write_file (obj_name);
			     ++obj_cnt;
			 }

			 strcpy (obj_name, new_obj_name);
			 printf ("Working on: %s\n", obj_name);
		     }
		     break;
	}
    }

    fclose (f);

    opt_write_pov (obj_name);
    ++obj_cnt;

    printf ("\n");

    g = fopen (outfile, "a");

    if (txtcnt > 0)
	fprintf (g, "\n/* Named textures, modify as needed */\n");

    for (i = 0; i < txtcnt; i++) {
	fprintf (g, "declare %s = texture {\n", txtlist[i]);
	fprintf (g, "    ambient 0.1\n");
	fprintf (g, "    diffuse 0.7\n");
	fprintf (g, "    phong 1.0\n");
	fprintf (g, "    phong_size 70.0\n");
	fprintf (g, "    color red 1.0 green 1.0 blue 1.0\n");
	fprintf (g, "}\n\n");

	free (txtlist[i]);
    }

    fclose(g);

    opt_finish();

    if (camera)
	make_camera();

    return 0;
}


void process_args (int argc, char *argv[])
{
    int i;

    printf ("\n");
    printf ("RAW to POV-Ray Converter %s - Copyright (c) 1993 Steve Anger\n", VERSION);
#if defined(__GNUC__) && defined(i386)
    printf ("32 bit version. DOS Extender Copyright (c) 1991 DJ Delorie\n");
#endif
    printf ("This program is freely distributable\n");
    printf ("\n");

    if (argc < 2) {
	printf ("Usage: raw2pov inputfile[.raw] [outputfile[.pov]] [[-/]options]\n\n");
	printf ("Options: -snnn  - Smooth triangles with angles < nnn\n");
	printf ("         -u     - Do not add nested bounds to output (unbounded)\n");
	printf ("         -v     - Verbose status messages\n");
	printf ("         -1     - Generate one object only\n");
	printf ("         -x     - Exchange the Y and Z coords\n");
	printf ("         -c     - Add camera and light source\n");
	printf ("         -fc    - Input file in fractint color format\n");
	printf ("         -ft    - Input file has textures specified\n");
	printf ("\nex. raw2pov chess.raw chess.pov -s60 -v\n\n");
	exit(1);
    }

    infile[0] = '\0';
    outfile[0] = '\0';
    smooth = 60.0;
    bound = 0;
    verbose = 0;
    one_object = 0;
    swap_yz = 0;
    camera = 0;
    format = DEFAULT;

    for (i = 1; i < argc; i++) {
	if (argv[i][0] == '-' || argv[i][0] == '/') {
	    switch (upcase(argv[i][1])) {
		case 'C': camera = 1;
			  break;

		case 'F': if (upcase(argv[i][2]) == 'C')
			      format = FRACTINT;
			  else if (upcase(argv[i][2]) == 'T')
			      format = TEXTURE;
			  break;

		case 'S': if (argv[i][2] == '\0')
			      smooth = 60.0;
			  else
			      sscanf (&argv[i][2], "%f", &smooth);
			  break;

		case 'U': bound = 2;
			  break;

		case 'V': verbose = 1;
			  break;

		case '1': one_object = 1;
			  break;

		case 'X': swap_yz = 1;
			  break;

		default : printf ("\nInvalid option -%c\n", argv[i][1]);
			  exit (1);
	    }
	}
	else if (infile[0] == '\0') {
	    strcpy (infile, argv[i]);
	    add_ext (infile, "raw", 0);
	}
	else if (outfile[0] == '\0') {
	    strcpy (outfile, argv[i]);
	    add_ext (outfile, "pov", 0);
	}
	else
	    abortmsg ("Too many file names specified.\n", 1);
    }

    if (outfile[0] == '\0') {
	strcpy (outfile, infile);
	add_ext (outfile, "pov", 1);
    }
}


char *next_token (FILE *f)
{
    static char token[128];
    int  index, comment;
    char ch;

    index = 0;
    comment = 0;

    strcpy (token, "");

    /* Skip the white space */
    while (1) {
	ch = fgetc (f);

	if (feof(f))
	    break;

	if (ch == '\n')
	   ++line_cnt;
	else if (ch == '{')
	    comment += 1;
	else if (ch == '}')
	    comment = (comment > 0) ? (comment - 1) : 0;
	else if (!isspace(ch) && !comment)
	    break;
    }

    if (feof(f))
	return token;

    ungetc (ch, f);

    while (1) {
	ch = fgetc (f);

	if (feof(f))
	   break;

	if (ch == '\n')
	    ++line_cnt;

	if (isspace(ch))
	    break;

	if (index < 127)
	    token[index++] = ch;
    }

    token[index] = '\0';

    return token;
}


int parse_input (FILE *f)
{
    int   token_cnt, expected, result;
    char  *token;
    char  tokens[12][64];

    token_cnt = 0;
    expected = 0;
    result = -1;

    /* How many tokens to expect per triangle */
    switch (format) {
	case DEFAULT:  expected = 9;
		       break;

	case FRACTINT: expected = 12;
		       break;

	case TEXTURE:  expected = 10;
		       break;
    }

    do {
	token = next_token (f);

	if (strlen(token) == 0)
	    break;

	if (!isdigit(token[0]) && token[0] != '+' && token[0] != '-') {
	    if (token_cnt == 0) {
		strcpy (new_obj_name, token);
		cleanup_name (new_obj_name);
		return 3; /* New object name */
	    }
	    else if (token_cnt != 9 || expected != 10) {
		printf ("Error in input file, line %ld. Misplaced object name.\n", line_cnt);
		exit(1);
	    }
	}

	strcpy (tokens[token_cnt++], token);
    } while (token_cnt < expected);

    if (token_cnt == 0)
	return 0; /* End of file */

    if (token_cnt != expected) {
	printf ("Error in input file, line %ld. Unexpected end of file.\n", line_cnt);
	exit(1);
    }

    switch (format) {
	case DEFAULT:  /* Ax Ay Az Bx By Bz Cx Cy Cz */
	    red   = 1.0;
	    green = 1.0;
	    blue  = 1.0;
	    ax    = atof(tokens[0]);
	    ay    = atof(tokens[1]);
	    az    = atof(tokens[2]);
	    bx    = atof(tokens[3]);
	    by    = atof(tokens[4]);
	    bz    = atof(tokens[5]);
	    cx    = atof(tokens[6]);
	    cy    = atof(tokens[7]);
	    cz    = atof(tokens[8]);
	    result = 1;
	    break;

	case FRACTINT:  /* R G B Ax Ay Az Bx By Bz Cx Cy Cz */
	    red   = atof(tokens[0]);
	    green = atof(tokens[1]);
	    blue  = atof(tokens[2]);
	    ax    = atof(tokens[3]);
	    ay    = atof(tokens[4]);
	    az    = atof(tokens[5]);
	    bx    = atof(tokens[6]);
	    by    = atof(tokens[7]);
	    bz    = atof(tokens[8]);
	    cx    = atof(tokens[9]);
	    cy    = atof(tokens[10]);
	    cz    = atof(tokens[11]);
	    result = 1;
	    break;

	case TEXTURE:  /* Ax Ay Az Bx By Bz Cx Cy Cz Texture */
	    ax    = atof(tokens[0]);
	    ay    = atof(tokens[1]);
	    az    = atof(tokens[2]);
	    bx    = atof(tokens[3]);
	    by    = atof(tokens[4]);
	    bz    = atof(tokens[5]);
	    cx    = atof(tokens[6]);
	    cy    = atof(tokens[7]);
	    cz    = atof(tokens[8]);
	    strcpy (new_texture, tokens[9]);
	    cleanup_name (new_texture);
	    result = 2;
	    break;
    }

    if (swap_yz) {
	fswap (&ay, &az);
	fswap (&by, &bz);
	fswap (&cy, &cz);
    }

    return result;
}


void make_camera()
{
    Vector gmin, gmax, look, size, scale;
    float  maxdim;
    FILE *f;

    f = fopen (outfile, "a");

    opt_get_glimits (&gmin.x, &gmin.y, &gmin.z, &gmax.x, &gmax.y, &gmax.z);

    look.x = (gmin.x + gmax.x)/2.0;
    look.y = (gmin.y + gmax.y)/2.0;
    look.z = (gmin.z + gmax.z)/2.0;

    size.x = gmax.x - gmin.x;
    size.y = gmax.y - gmin.y;
    size.z = gmax.z - gmin.z;

    maxdim = -MAXINT;

    if (size.x > maxdim) maxdim = size.x;
    if (size.y > maxdim) maxdim = size.y;
    if (size.z > maxdim) maxdim = size.z;

    if (size.x > size.z) {
	scale.x =  0.3;
	scale.y =  0.4;
	scale.z = -1.3;
    }
    else {
	scale.x = 1.3;
	scale.y = 0.4;
	scale.z = 0.3;
    }

    fprintf (f, "camera {\n");
    fprintf (f, "    location <%.4f %.4f %.4f>\n",
		     scale.x * maxdim + look.x,
		     scale.y * maxdim + look.y,
		     scale.z * maxdim + look.z);
    fprintf (f, "    look_at <%.4f %.4f %.4f>\n", look.x, look.y, look.z);
    fprintf (f, "}\n\n");

    fprintf (f, "object {\n");
    fprintf (f, "    light_source { <%.4f %.4f %.4f> color red 1 green 1 blue 1 }\n",
		     4.0 * scale.x * maxdim + look.x,
		     4.0 * scale.y * maxdim + look.y,
		     4.0 * scale.z * maxdim + look.z);
    fprintf (f, "}\n\n");

    fclose(f);
}


void update_txtlist (char *new_texture)
{
    int i;

    for (i = 0; i < txtcnt; i++) {
	if (strcmp (new_texture, txtlist[i]) == 0)
	    break;
    }

    if (i < txtcnt)
	return;

    if (i == MAX_TEXTURE)
	abortmsg ("Too many textures", 1);

    txtlist[i] = malloc (strlen (new_texture) + 1);
    strcpy (txtlist[i], new_texture);

    ++txtcnt;
}


void fswap (float *a, float *b)
{
    float temp;

    temp = *a;
    *a = *b;
    *b = temp;
}


/* Convert character 'c' top upper case */
char upcase (char c)
{
    if (c >= 'a' && c <= 'z')
	c = c - 'a' + 'A';

    return c;
}
